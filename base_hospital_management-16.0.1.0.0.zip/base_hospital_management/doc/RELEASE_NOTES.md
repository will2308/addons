## Module <base_hospital_management>

#### 27.12.2023
#### Version 16.0.1.0.0
#### ADD

- Initial commit for Hospital Management Odoo 16
